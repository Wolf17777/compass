
$("#confirm_delete_totp_pin_container").on('keydown', {pin_id: "confirm_delete_totp" }, pincode_keydown);
$("#confirm_delete_totp_pin_container").on('input', {pin_id: "confirm_delete_totp" }, pincode_input);
$("#confirm_delete_totp_pin_container").on('keyup', {pin_id: "confirm_delete_totp" }, pincode_keyup);
